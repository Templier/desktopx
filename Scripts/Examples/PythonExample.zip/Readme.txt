This is an example object using a script component with code written in Python.

This requires the python scripting engine to be installed and registered on the user computer.

ActivePython has an installer that does everything for you. You can find the latest version here:
http://www.activestate.com/activepython/

Simply install it and then load the object.